# Dralvo GoldWave — 2 preset (backtest real-tick GTC XAUUSD, 09/2023–07/2026)

EA: scalp Vàng — chỉ vào khi **sideway M1** (ADX + range, mean-reversion tại biên) → **SAR-martingale ×N** (thua→đảo chiều+nhân lot, thắng→reset) → cap bước + equity-guard.
Cả 2 preset chạy trên EA `Dralvo_GoldWave.ex5`, nạp tab **Inputs → Load**.

## So sánh (base lot 0.01, full 34 tháng)

| | **GoldWave_Safe** ⭐ | **GoldWave_HighProfit** |
|---|---|---|
| Multiplier / Cap bước | 2.0 / 8 | 2.75 / 10 |
| SL / TP (points) | 1100 / 1600 | 1000 / 1600 |
| ADX_Max / Lookback / Edge | 28 / 120 / 0.45 | 28 / 120 / 0.45 |
| **Net 34 tháng** | +61.290 | +730.315 |
| Profit Factor | 1,20 | 1,26 |
| Bước sâu tối đa | 8 | 10 |
| **Lot ở bước đuôi** | **1,3** | **89,9** |
| **Ký quỹ ôm lot đuôi** | $5.248 | $368.789 |
| Max DD (tuyệt đối) | $12.800 | $87.400 |
| **VỐN TỐI THIỂU an toàn (base 0.01)** | **~$43.000** | **~$434.000** |
| Return / vốn tối thiểu đó | 144% | 168% |
| EquityGuard | 50% | 40% |

## Đọc đúng bản chất (quan trọng)
- **HighProfit KHÔNG lãi gấp 12 lần thực sự.** Nó chạy cùng base 0.01 nhưng **cần vốn gấp ~10 lần** để ôm được lot đuôi (89,9 lot). Chuẩn hoá theo vốn: chỉ hơn ~1,2 lần (168% vs 144%).
- **Đòn bẩy tạo profit = Multiplier**, đổi lại **rủi ro đuôi hàm mũ**: nếu 1 chuỗi tương lai vượt bước 10 (ngoài backtest), lot/lỗ ×2,75 lần → "34 tháng không cháy" KHÔNG bảo đảm không cháy sau này.

## Chọn preset nào?
- **Vốn < $100k / ưu tiên an toàn → Safe.** Lot đuôi 1,3, dễ ôm, DD nhỏ.
- **Vốn ≥ $450k / chịu rủi ro đuôi → HighProfit.** Return %/vốn nhỉnh hơn, PF cao hơn — nhưng phải ôm nổi 90 lot lúc chuỗi sâu.
- **Không đủ vốn cho HighProfit thì ĐỪNG dùng** — chạm bước 10 = margin call = cháy (backtest vốn lớn đã giấu điều này).

## Scale theo vốn (base lot)
Base 0.01 là mức tham chiếu. Vốn lớn hơn → tăng base lot **tỉ lệ thuận** (profit & lot đuôi & vốn-cần-thiết cùng scale). Vốn nhỏ hơn min → KHÔNG chạy được (min lot sàn 0.01).

*Backtest quá khứ không đảm bảo tương lai. Martingale có rủi ro cháy tài khoản khi trend mạnh kéo dài vượt cap.*
